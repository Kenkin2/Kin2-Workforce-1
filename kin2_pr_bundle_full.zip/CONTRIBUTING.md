# Contributing
- Conventional Commits (`feat:`, `fix:`, `chore:`)
- `npm ci && npm run lint && npm test` before PR
