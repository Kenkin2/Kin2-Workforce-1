---
name: Feature request
about: Suggest an idea
labels: enhancement
---
**Problem**
**Proposed solution**
**Alternatives**
**Additional context**
