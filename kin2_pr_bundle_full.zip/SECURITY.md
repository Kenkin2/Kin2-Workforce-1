# Security Policy
- Report via GitHub Security Advisories (private).
- Avoid public issues for vulnerabilities.
- Target triage: 72 hours.
