# Changelog
## [v0.1.0] - 2025-10-02
- Add CI, Security, Release workflows
- Add Compose, OpenAPI, health routes, docs
